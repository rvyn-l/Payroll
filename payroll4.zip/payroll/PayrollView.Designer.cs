﻿namespace Payroll
{
    partial class PayrollView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PayrollList = new System.Windows.Forms.Label();
            this.Addpay = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // PayrollList
            // 
            this.PayrollList.AutoSize = true;
            this.PayrollList.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PayrollList.Location = new System.Drawing.Point(33, 48);
            this.PayrollList.Name = "PayrollList";
            this.PayrollList.Size = new System.Drawing.Size(158, 32);
            this.PayrollList.TabIndex = 3;
            this.PayrollList.Text = "PayrollList";
            // 
            // Addpay
            // 
            this.Addpay.BackColor = System.Drawing.Color.Black;
            this.Addpay.FlatAppearance.BorderSize = 0;
            this.Addpay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addpay.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addpay.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Addpay.Location = new System.Drawing.Point(841, 29);
            this.Addpay.Name = "Addpay";
            this.Addpay.Size = new System.Drawing.Size(158, 51);
            this.Addpay.TabIndex = 5;
            this.Addpay.Text = "ADD PAYROLL";
            this.Addpay.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(243)))));
            this.panel4.Location = new System.Drawing.Point(50, 136);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(959, 515);
            this.panel4.TabIndex = 6;
            // 
            // PayrollView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(245)))), ((int)(((byte)(236)))));
            this.ClientSize = new System.Drawing.Size(1056, 696);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.Addpay);
            this.Controls.Add(this.PayrollList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PayrollView";
            this.Text = "PayrollView";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PayrollList;
        private System.Windows.Forms.Button Addpay;
        private System.Windows.Forms.Panel panel4;
    }
}
﻿namespace Payroll
{
    partial class Attendance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AttendanceList = new System.Windows.Forms.Label();
            this.AddAtt = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // AttendanceList
            // 
            this.AttendanceList.AutoSize = true;
            this.AttendanceList.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AttendanceList.Location = new System.Drawing.Point(33, 48);
            this.AttendanceList.Name = "AttendanceList";
            this.AttendanceList.Size = new System.Drawing.Size(218, 32);
            this.AttendanceList.TabIndex = 1;
            this.AttendanceList.Text = "AttendanceList";
            // 
            // AddAtt
            // 
            this.AddAtt.BackColor = System.Drawing.Color.Black;
            this.AddAtt.FlatAppearance.BorderSize = 0;
            this.AddAtt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddAtt.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddAtt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.AddAtt.Location = new System.Drawing.Point(841, 29);
            this.AddAtt.Name = "AddAtt";
            this.AddAtt.Size = new System.Drawing.Size(158, 51);
            this.AddAtt.TabIndex = 3;
            this.AddAtt.Text = "ADD ATTENDANCE";
            this.AddAtt.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(243)))));
            this.panel2.Location = new System.Drawing.Point(50, 136);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(959, 515);
            this.panel2.TabIndex = 4;
            // 
            // Attendance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(245)))), ((int)(((byte)(236)))));
            this.ClientSize = new System.Drawing.Size(1056, 696);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.AddAtt);
            this.Controls.Add(this.AttendanceList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Attendance";
            this.Text = "Attendance";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AttendanceList;
        private System.Windows.Forms.Button AddAtt;
        private System.Windows.Forms.Panel panel2;
    }
}
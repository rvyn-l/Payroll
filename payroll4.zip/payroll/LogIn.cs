﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Payroll
{
    public partial class LogIn : Form
    {
        bool drag = false;
        Point start_point = new Point(0, 0);

        public LogIn()
        {
            InitializeComponent();
  
        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            TextLog.Parent = bonBox;
            TextLog.BackColor = Color.Transparent;
            UserText.Parent = bonBox;
            UserText.BackColor = Color.Transparent;
            PassText.Parent = bonBox;
            PassText.BackColor = Color.Transparent;
            CircleBox.Parent = bonBox;
            CircleBox.BackColor = Color.Transparent;
            CircleBox1.Parent = bonBox;
            CircleBox1.BackColor = Color.Transparent;
            Lock.Parent = bonBox;
            Lock.BackColor = Color.Transparent;
            User.Parent = bonBox;
            User.BackColor = Color.Transparent;

            Close.Parent = bonBox;
            Close.BackColor = Color.Transparent;
            MinimizeBtn.Parent = bonBox;
            MinimizeBtn.BackColor = Color.Transparent;

            LogBtn.Parent = bonBox;
            LogBtn.BackColor = Color.Transparent;

          

        }

        
        private void bonBox_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void CircleBox_Click(object sender, EventArgs e)
        {

        }

        private void TextLog_Click(object sender, EventArgs e)
        {

        }

        private void LogBtn_Click(object sender, EventArgs e)
        {
            string user = txtUsername.Text;
            string password = txtPassword.Text;

            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=payroll;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM admin WHERE username = @user AND password = @password";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@user", user);
                    cmd.Parameters.AddWithValue("@password", password);
                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    if (count > 0)
                    {
                        DashboardForm DashboardForm = new DashboardForm();
                        DashboardForm.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("invalid");
                    }
                }

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Minimized;
            }
            else if (WindowState == FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Normal;
            }

        }

        private void bonBox_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            start_point = new Point(e.X, e.Y);
        }

        private void bonBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag)
            {
                Point p = PointToScreen(e.Location);
                this.Location = new Point(p.X-start_point.X,p.Y-start_point.Y);
            }
        }

        private void bonBox_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }
    }
    }


﻿namespace Payroll
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TextLog = new System.Windows.Forms.Label();
            this.UserText = new System.Windows.Forms.Label();
            this.PassText = new System.Windows.Forms.Label();
            this.LogBtn = new System.Windows.Forms.Button();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.Close = new System.Windows.Forms.Button();
            this.MinimizeBtn = new System.Windows.Forms.Button();
            this.User = new System.Windows.Forms.PictureBox();
            this.Lock = new System.Windows.Forms.PictureBox();
            this.CircleBox1 = new System.Windows.Forms.PictureBox();
            this.CircleBox = new System.Windows.Forms.PictureBox();
            this.bonBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.User)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CircleBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CircleBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bonBox)).BeginInit();
            this.SuspendLayout();
            // 
            // TextLog
            // 
            this.TextLog.AutoSize = true;
            this.TextLog.BackColor = System.Drawing.Color.Transparent;
            this.TextLog.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextLog.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TextLog.Location = new System.Drawing.Point(526, 87);
            this.TextLog.Name = "TextLog";
            this.TextLog.Size = new System.Drawing.Size(326, 48);
            this.TextLog.TabIndex = 1;
            this.TextLog.Text = "ACCOUNT LOGIN";
            this.TextLog.Click += new System.EventHandler(this.TextLog_Click);
            // 
            // UserText
            // 
            this.UserText.AutoSize = true;
            this.UserText.BackColor = System.Drawing.Color.Transparent;
            this.UserText.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserText.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.UserText.Location = new System.Drawing.Point(618, 198);
            this.UserText.Name = "UserText";
            this.UserText.Size = new System.Drawing.Size(124, 29);
            this.UserText.TabIndex = 2;
            this.UserText.Text = "Username";
            this.UserText.Click += new System.EventHandler(this.label1_Click);
            // 
            // PassText
            // 
            this.PassText.AutoSize = true;
            this.PassText.BackColor = System.Drawing.Color.Transparent;
            this.PassText.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PassText.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.PassText.Location = new System.Drawing.Point(619, 306);
            this.PassText.Name = "PassText";
            this.PassText.Size = new System.Drawing.Size(120, 29);
            this.PassText.TabIndex = 3;
            this.PassText.Text = "Password";
            this.PassText.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // LogBtn
            // 
            this.LogBtn.BackColor = System.Drawing.Color.Transparent;
            this.LogBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.LogBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.LogBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(125)))), ((int)(((byte)(132)))));
            this.LogBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(142)))), ((int)(((byte)(153)))));
            this.LogBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogBtn.ForeColor = System.Drawing.Color.White;
            this.LogBtn.Location = new System.Drawing.Point(614, 446);
            this.LogBtn.Name = "LogBtn";
            this.LogBtn.Size = new System.Drawing.Size(144, 54);
            this.LogBtn.TabIndex = 8;
            this.LogBtn.Text = "LOG IN";
            this.LogBtn.UseVisualStyleBackColor = false;
            this.LogBtn.Click += new System.EventHandler(this.LogBtn_Click);
            // 
            // txtUsername
            // 
            this.txtUsername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUsername.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.Location = new System.Drawing.Point(594, 248);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(187, 16);
            this.txtUsername.TabIndex = 9;
            this.txtUsername.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPassword.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(594, 359);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(187, 16);
            this.txtPassword.TabIndex = 10;
            this.txtPassword.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.FlatAppearance.BorderSize = 0;
            this.Close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(125)))), ((int)(((byte)(132)))));
            this.Close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(142)))), ((int)(((byte)(153)))));
            this.Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Close.ForeColor = System.Drawing.Color.Transparent;
            this.Close.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Close.Location = new System.Drawing.Point(829, 12);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(59, 43);
            this.Close.TabIndex = 11;
            this.Close.Text = "X";
            this.Close.UseVisualStyleBackColor = false;
            this.Close.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // MinimizeBtn
            // 
            this.MinimizeBtn.BackColor = System.Drawing.Color.Transparent;
            this.MinimizeBtn.FlatAppearance.BorderSize = 0;
            this.MinimizeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(125)))), ((int)(((byte)(132)))));
            this.MinimizeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(142)))), ((int)(((byte)(153)))));
            this.MinimizeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MinimizeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimizeBtn.ForeColor = System.Drawing.Color.Transparent;
            this.MinimizeBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.MinimizeBtn.Location = new System.Drawing.Point(764, 12);
            this.MinimizeBtn.Name = "MinimizeBtn";
            this.MinimizeBtn.Size = new System.Drawing.Size(59, 43);
            this.MinimizeBtn.TabIndex = 12;
            this.MinimizeBtn.Text = "--";
            this.MinimizeBtn.UseVisualStyleBackColor = false;
            this.MinimizeBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // User
            // 
            this.User.BackColor = System.Drawing.Color.Transparent;
            this.User.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.User.Image = global::Payroll.Properties.Resources.User1;
            this.User.Location = new System.Drawing.Point(509, 234);
            this.User.Name = "User";
            this.User.Size = new System.Drawing.Size(39, 44);
            this.User.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.User.TabIndex = 7;
            this.User.TabStop = false;
            // 
            // Lock
            // 
            this.Lock.BackColor = System.Drawing.Color.Transparent;
            this.Lock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Lock.Image = global::Payroll.Properties.Resources.Lock1;
            this.Lock.Location = new System.Drawing.Point(509, 345);
            this.Lock.Name = "Lock";
            this.Lock.Size = new System.Drawing.Size(39, 44);
            this.Lock.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Lock.TabIndex = 6;
            this.Lock.TabStop = false;
            // 
            // CircleBox1
            // 
            this.CircleBox1.BackColor = System.Drawing.Color.Transparent;
            this.CircleBox1.Image = global::Payroll.Properties.Resources.textBox1;
            this.CircleBox1.Location = new System.Drawing.Point(554, 306);
            this.CircleBox1.Name = "CircleBox1";
            this.CircleBox1.Size = new System.Drawing.Size(266, 114);
            this.CircleBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CircleBox1.TabIndex = 5;
            this.CircleBox1.TabStop = false;
            this.CircleBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // CircleBox
            // 
            this.CircleBox.BackColor = System.Drawing.Color.Transparent;
            this.CircleBox.Image = global::Payroll.Properties.Resources.textBox1;
            this.CircleBox.Location = new System.Drawing.Point(554, 198);
            this.CircleBox.Name = "CircleBox";
            this.CircleBox.Size = new System.Drawing.Size(266, 114);
            this.CircleBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CircleBox.TabIndex = 4;
            this.CircleBox.TabStop = false;
            this.CircleBox.Click += new System.EventHandler(this.CircleBox_Click);
            // 
            // bonBox
            // 
            this.bonBox.BackColor = System.Drawing.Color.Transparent;
            this.bonBox.Image = global::Payroll.Properties.Resources.Bon;
            this.bonBox.Location = new System.Drawing.Point(0, -1);
            this.bonBox.Name = "bonBox";
            this.bonBox.Size = new System.Drawing.Size(902, 627);
            this.bonBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bonBox.TabIndex = 0;
            this.bonBox.TabStop = false;
            this.bonBox.Click += new System.EventHandler(this.bonBox_Click);
            this.bonBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.bonBox_MouseDown);
            this.bonBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.bonBox_MouseMove);
            this.bonBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.bonBox_MouseUp);
            // 
            // LogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 625);
            this.Controls.Add(this.MinimizeBtn);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.LogBtn);
            this.Controls.Add(this.User);
            this.Controls.Add(this.Lock);
            this.Controls.Add(this.PassText);
            this.Controls.Add(this.UserText);
            this.Controls.Add(this.CircleBox1);
            this.Controls.Add(this.CircleBox);
            this.Controls.Add(this.TextLog);
            this.Controls.Add(this.bonBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LogIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.LogIn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.User)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CircleBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CircleBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bonBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox bonBox;
        private System.Windows.Forms.Label TextLog;
        private System.Windows.Forms.Label UserText;
        private System.Windows.Forms.Label PassText;
        private System.Windows.Forms.PictureBox CircleBox;
        private System.Windows.Forms.PictureBox CircleBox1;
        private System.Windows.Forms.PictureBox Lock;
        private System.Windows.Forms.PictureBox User;
        private System.Windows.Forms.Button LogBtn;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button MinimizeBtn;
    }
}


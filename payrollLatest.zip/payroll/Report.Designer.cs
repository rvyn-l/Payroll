﻿namespace Payroll
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReportList = new System.Windows.Forms.Label();
            this.Addrep = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // ReportList
            // 
            this.ReportList.AutoSize = true;
            this.ReportList.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportList.Location = new System.Drawing.Point(33, 48);
            this.ReportList.Name = "ReportList";
            this.ReportList.Size = new System.Drawing.Size(154, 32);
            this.ReportList.TabIndex = 2;
            this.ReportList.Text = "ReportList";
            // 
            // Addrep
            // 
            this.Addrep.BackColor = System.Drawing.Color.Black;
            this.Addrep.FlatAppearance.BorderSize = 0;
            this.Addrep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addrep.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addrep.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Addrep.Location = new System.Drawing.Point(841, 29);
            this.Addrep.Name = "Addrep";
            this.Addrep.Size = new System.Drawing.Size(158, 51);
            this.Addrep.TabIndex = 4;
            this.Addrep.Text = "ADD REPORT";
            this.Addrep.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(243)))));
            this.panel3.Location = new System.Drawing.Point(50, 136);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(959, 515);
            this.panel3.TabIndex = 5;
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(245)))), ((int)(((byte)(236)))));
            this.ClientSize = new System.Drawing.Size(1056, 696);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Addrep);
            this.Controls.Add(this.ReportList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Report";
            this.Text = "Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ReportList;
        private System.Windows.Forms.Button Addrep;
        private System.Windows.Forms.Panel panel3;
    }
}
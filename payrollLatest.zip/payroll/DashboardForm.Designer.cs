﻿namespace Payroll
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.gradientPanel2 = new Payroll.GradientPanel();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.CLOSE = new System.Windows.Forms.Button();
            this.Grad = new Payroll.GradientPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dsh = new System.Windows.Forms.Button();
            this.att = new System.Windows.Forms.Button();
            this.rep = new System.Windows.Forms.Button();
            this.pay = new System.Windows.Forms.Button();
            this.emp = new System.Windows.Forms.Button();
            this.Sample = new Payroll.GradientPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.FormDash = new Payroll.GradientPanel();
            this.gradientPanel2.SuspendLayout();
            this.Grad.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(0)))), ((int)(((byte)(4)))));
            this.panel1.Location = new System.Drawing.Point(274, 211);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 5);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(0)))), ((int)(((byte)(4)))));
            this.panel4.Location = new System.Drawing.Point(274, 756);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1000, 5);
            this.panel4.TabIndex = 6;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // gradientPanel2
            // 
            this.gradientPanel2.Angle = 0F;
            this.gradientPanel2.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.gradientPanel2.Controls.Add(this.button2);
            this.gradientPanel2.Controls.Add(this.button4);
            this.gradientPanel2.Controls.Add(this.button3);
            this.gradientPanel2.Controls.Add(this.button1);
            this.gradientPanel2.Controls.Add(this.label3);
            this.gradientPanel2.Controls.Add(this.CLOSE);
            this.gradientPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.gradientPanel2.Location = new System.Drawing.Point(246, 0);
            this.gradientPanel2.Name = "gradientPanel2";
            this.gradientPanel2.Size = new System.Drawing.Size(1056, 94);
            this.gradientPanel2.TabIndex = 20;
            this.gradientPanel2.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(123)))), ((int)(((byte)(125)))));
            this.gradientPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.gradientPanel2_Paint);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RosyBrown;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(915, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(72, 58);
            this.button2.TabIndex = 18;
            this.button2.Text = "-";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RosyBrown;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(984, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(72, 58);
            this.button4.TabIndex = 17;
            this.button4.Text = "X";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.Transparent;
            this.button3.Image = global::Payroll.Properties.Resources.user__2_;
            this.button3.Location = new System.Drawing.Point(863, 31);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(46, 38);
            this.button3.TabIndex = 15;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RosyBrown;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(1026, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(72, 58);
            this.button1.TabIndex = 14;
            this.button1.Text = "-";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(810, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 16);
            this.label3.TabIndex = 16;
            this.label3.Text = "admin";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // CLOSE
            // 
            this.CLOSE.BackColor = System.Drawing.Color.Transparent;
            this.CLOSE.FlatAppearance.BorderSize = 0;
            this.CLOSE.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.CLOSE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RosyBrown;
            this.CLOSE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CLOSE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CLOSE.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CLOSE.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CLOSE.Location = new System.Drawing.Point(1095, 12);
            this.CLOSE.Name = "CLOSE";
            this.CLOSE.Size = new System.Drawing.Size(72, 58);
            this.CLOSE.TabIndex = 13;
            this.CLOSE.Text = "X";
            this.CLOSE.UseVisualStyleBackColor = false;
            this.CLOSE.Click += new System.EventHandler(this.CLOSE_Click);
            // 
            // Grad
            // 
            this.Grad.Angle = 90F;
            this.Grad.BackColor = System.Drawing.Color.RosyBrown;
            this.Grad.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(183)))));
            this.Grad.Controls.Add(this.panel2);
            this.Grad.Controls.Add(this.dsh);
            this.Grad.Controls.Add(this.att);
            this.Grad.Controls.Add(this.rep);
            this.Grad.Controls.Add(this.pay);
            this.Grad.Controls.Add(this.emp);
            this.Grad.Controls.Add(this.Sample);
            this.Grad.Controls.Add(this.panel3);
            this.Grad.Controls.Add(this.Logo);
            this.Grad.Dock = System.Windows.Forms.DockStyle.Left;
            this.Grad.Location = new System.Drawing.Point(0, 0);
            this.Grad.Name = "Grad";
            this.Grad.Size = new System.Drawing.Size(246, 785);
            this.Grad.TabIndex = 19;
            this.Grad.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(236)))));
            this.Grad.Paint += new System.Windows.Forms.PaintEventHandler(this.Grad_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(0)))), ((int)(((byte)(4)))));
            this.panel2.Location = new System.Drawing.Point(12, 756);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(212, 5);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // dsh
            // 
            this.dsh.BackColor = System.Drawing.Color.Transparent;
            this.dsh.FlatAppearance.BorderSize = 0;
            this.dsh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.dsh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RosyBrown;
            this.dsh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dsh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dsh.Image = global::Payroll.Properties.Resources.Home31;
            this.dsh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dsh.Location = new System.Drawing.Point(0, 268);
            this.dsh.Name = "dsh";
            this.dsh.Size = new System.Drawing.Size(243, 45);
            this.dsh.TabIndex = 12;
            this.dsh.Text = "DASHBOARD";
            this.dsh.UseVisualStyleBackColor = false;
            this.dsh.Click += new System.EventHandler(this.dsh_Click);
            // 
            // att
            // 
            this.att.BackColor = System.Drawing.Color.Transparent;
            this.att.FlatAppearance.BorderSize = 0;
            this.att.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.att.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RosyBrown;
            this.att.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.att.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.att.Image = global::Payroll.Properties.Resources.clock;
            this.att.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.att.Location = new System.Drawing.Point(0, 370);
            this.att.Name = "att";
            this.att.Size = new System.Drawing.Size(246, 45);
            this.att.TabIndex = 14;
            this.att.Text = "ATTENDANCE";
            this.att.UseVisualStyleBackColor = false;
            this.att.Click += new System.EventHandler(this.att_Click);
            // 
            // rep
            // 
            this.rep.BackColor = System.Drawing.Color.Transparent;
            this.rep.FlatAppearance.BorderSize = 0;
            this.rep.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.rep.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RosyBrown;
            this.rep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rep.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rep.Image = global::Payroll.Properties.Resources.file;
            this.rep.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rep.Location = new System.Drawing.Point(0, 472);
            this.rep.Name = "rep";
            this.rep.Size = new System.Drawing.Size(246, 45);
            this.rep.TabIndex = 16;
            this.rep.Text = "REPORT         ";
            this.rep.UseVisualStyleBackColor = false;
            this.rep.Click += new System.EventHandler(this.rep_Click);
            // 
            // pay
            // 
            this.pay.BackColor = System.Drawing.Color.Transparent;
            this.pay.FlatAppearance.BorderSize = 0;
            this.pay.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.pay.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RosyBrown;
            this.pay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pay.Image = global::Payroll.Properties.Resources.dollar;
            this.pay.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pay.Location = new System.Drawing.Point(0, 421);
            this.pay.Name = "pay";
            this.pay.Size = new System.Drawing.Size(246, 45);
            this.pay.TabIndex = 15;
            this.pay.Text = "PAYROLL       ";
            this.pay.UseVisualStyleBackColor = false;
            this.pay.Click += new System.EventHandler(this.pay_Click);
            // 
            // emp
            // 
            this.emp.BackColor = System.Drawing.Color.Transparent;
            this.emp.FlatAppearance.BorderSize = 0;
            this.emp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.emp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RosyBrown;
            this.emp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.emp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emp.Image = global::Payroll.Properties.Resources.employees;
            this.emp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.emp.Location = new System.Drawing.Point(0, 319);
            this.emp.Name = "emp";
            this.emp.Size = new System.Drawing.Size(246, 45);
            this.emp.TabIndex = 13;
            this.emp.Text = "EMPLOYEES  ";
            this.emp.UseVisualStyleBackColor = false;
            this.emp.Click += new System.EventHandler(this.emp_Click);
            // 
            // Sample
            // 
            this.Sample.Angle = 0F;
            this.Sample.BottomColor = System.Drawing.Color.Empty;
            this.Sample.Location = new System.Drawing.Point(246, 118);
            this.Sample.Name = "Sample";
            this.Sample.Size = new System.Drawing.Size(1176, 903);
            this.Sample.TabIndex = 0;
            this.Sample.TopColor = System.Drawing.Color.Empty;
            this.Sample.Paint += new System.Windows.Forms.PaintEventHandler(this.Sample_Paint);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(0)))), ((int)(((byte)(4)))));
            this.panel3.Location = new System.Drawing.Point(12, 211);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(212, 5);
            this.panel3.TabIndex = 4;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // Logo
            // 
            this.Logo.BackColor = System.Drawing.Color.Transparent;
            this.Logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.Logo.Image = global::Payroll.Properties.Resources.BonLogo;
            this.Logo.Location = new System.Drawing.Point(0, 0);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(246, 247);
            this.Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Logo.TabIndex = 2;
            this.Logo.TabStop = false;
            this.Logo.Click += new System.EventHandler(this.Logo_Click);
            // 
            // FormDash
            // 
            this.FormDash.Angle = 0F;
            this.FormDash.BottomColor = System.Drawing.Color.Empty;
            this.FormDash.Location = new System.Drawing.Point(246, 89);
            this.FormDash.Name = "FormDash";
            this.FormDash.Size = new System.Drawing.Size(1056, 696);
            this.FormDash.TabIndex = 21;
            this.FormDash.TopColor = System.Drawing.Color.Empty;
            this.FormDash.Paint += new System.Windows.Forms.PaintEventHandler(this.FormDash_Paint);
            // 
            // DashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(245)))), ((int)(((byte)(236)))));
            this.ClientSize = new System.Drawing.Size(1302, 785);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gradientPanel2);
            this.Controls.Add(this.Grad);
            this.Controls.Add(this.FormDash);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DashboardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashboardForm";
            this.gradientPanel2.ResumeLayout(false);
            this.gradientPanel2.PerformLayout();
            this.Grad.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GradientPanel Grad;
        private GradientPanel Sample;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.Button dsh;
        private System.Windows.Forms.Button att;
        private System.Windows.Forms.Button rep;
        private System.Windows.Forms.Button pay;
        private System.Windows.Forms.Button emp;
        private GradientPanel gradientPanel2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button CLOSE;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private GradientPanel FormDash;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Linq.Expressions;
using MySql.Data.MySqlClient;
using System.Xml;
using MySqlX.XDevAPI.Common;

namespace Payroll
{
    public partial class addAttendance : Form
    {
        public addAttendance()
        {
            InitializeComponent();
            FillComboBox();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Position_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string connectionString = "server=127.0.0.1;port=3306;username=root;password=;database=payroll;";
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                string sql = "SELECT * FROM employees where Employee_ID = '" + comboBox1.Text+"';";
                MySqlCommand cmd = new MySqlCommand(sql, con);
                MySqlDataReader myReader;
                try
                {
                    con.Open();
                    myReader = cmd.ExecuteReader();
                    while (myReader.Read())
                    {
                        string Employee_ID = myReader.GetString(0);
                        string Fname = myReader.GetString(1);
                        string Lname = myReader.GetString(2);
                        txtFname.Text = Fname;
                        txtLname.Text = Lname;
                    }
                }



                catch (Exception ex)
                {
                    MessageBox.Show("Warning: " + ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        public void FillComboBox()
        {
            string connectionString = "server=127.0.0.1;port=3306;username=root;password=;database=payroll;";
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                string sql = "SELECT * FROM employees";
                MySqlCommand cmd = new MySqlCommand(sql, con);
                MySqlDataReader myReader;
                try
                {
                    con.Open();
                    myReader = cmd.ExecuteReader();
                    while (myReader.Read())
                    {
                        string employeeID = myReader.GetString(0);
                        comboBox1.Items.Add(employeeID);
                    }
                }



                catch (Exception ex)
                {
                    MessageBox.Show("Warning: " + ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }



            }
        }
        private void addAttendance_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private int result;
        private void txtTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddEmp_Click(object sender, EventArgs e)
        {
            string connectionString = "server=127.0.0.1;port=3306;username=root;password=;database=payroll;";
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                int Workdays = Convert.ToInt32(txtWorkDays.Text);
                int Npaid = Convert.ToInt32(txtNpaid.Text);

                result = Workdays - Npaid;
                txtTotal.Text = result.ToString();

                string sql = "INSERT INTO attendance (Employee_ID, Working_days, paid_leave, non_paid_leave, Days_Payable) VALUES ('" + this.comboBox1.Text + "', '" + this.txtWorkDays.Text + "', '" + this.txtPaid.Text + "', '" + this.txtNpaid.Text + "', '" + this.result.ToString() + "')";
                try
                {
                    con.Open();
                    MySqlCommand command = new MySqlCommand(sql, con);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Employee added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Warning: " + ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }


            }


        }
    }
}

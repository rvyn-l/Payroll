﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Payroll
{
    public partial class Attendance : Form
    {
        MySqlConnection con = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=;database=payroll");
        public Attendance()
        {
            InitializeComponent();
            GetData();
        }

        private void AddAtt_Click(object sender, EventArgs e)
        {
            addAttendance frm = new addAttendance();
            frm.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void GetData()
        {
            MySqlCommand cmd = new MySqlCommand("select * from attendance", con);
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = cmd;
            DataTable tab = new DataTable();
            adapter.Fill(tab);
            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = tab;
            dataGridView1.DataSource = bindingSource;
            adapter.Update(tab);
        }
    }
}

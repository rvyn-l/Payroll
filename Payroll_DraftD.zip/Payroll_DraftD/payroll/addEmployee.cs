﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payroll
{
    public partial class addEmployee : Form
    {
        MySqlConnection cn;
        MySqlCommand cm;
        MySqlDataReader dr;
        addemp clscon = new addemp();
        Employee f1;
        public addEmployee(Employee frm1)
        {
            InitializeComponent();
            cn = new MySqlConnection(clscon.dbconnect());
            f1 = frm1;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void gradientPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void CLOSE_Click(object sender, EventArgs e)
        {

        }

        private void AddEmpPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Fname_TextChanged(object sender, EventArgs e)
        {

        }

        public void Clear()
        {
            textBox1.Clear();
            Fname.Clear();
            Lname.Clear();
            Gender.Clear();
            Bday.Clear();
            Address.Clear();
            Phone.Clear();
            Email.Clear();
            Position.Clear();
            AddEmp.Enabled = true;
            update.Enabled = false;
        }

        private void AddEmp_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    if ((textBox1.Text == string.Empty || Fname.Text == string.Empty) || (Lname.Text == string.Empty) || (Gender.Text == string.Empty) || (Bday.Text == string.Empty) || (Address.Text == string.Empty || (Phone.Text == string.Empty) || (Email.Text == string.Empty) || (Position.Text == string.Empty)))
                    {
                        MessageBox.Show("Required empty field!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    cn.Open();
                    cm = new MySqlCommand("insert into employees (Employee_ID, Fname, Lname, Gender, DOB, Address, Phone, Email, Position_ID) values('" + this.textBox1.Text + "','" + this.Fname.Text + "', '" + this.Lname.Text + "','" + this.Gender.Text + "', '" + this.Bday.Text + "','" + this.Address.Text + "', '" + this.Phone.Text + "', '" + this.Email.Text + "','" + this.Position.Text + "')", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Record has been successfully saved", "Employee information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    f1.LoadRecords();
                }
                catch (Exception ex)
                {
                    cn.Close();
                    MessageBox.Show("Warning: " + ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void update_Click(object sender, EventArgs e)
        {
            try
            {
                if ((textBox1.Text == string.Empty || Fname.Text == string.Empty) || (Lname.Text == string.Empty) || (Gender.Text == string.Empty) || (Bday.Text == string.Empty) || (Address.Text == string.Empty || (Phone.Text == string.Empty) || (Email.Text == string.Empty) || (Position.Text == string.Empty)))
                {
                    MessageBox.Show("Required empty field!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                cn.Open();
                cm = new MySqlCommand("update employees set Fname = '" + Fname.Text + "', Lname = '" + Lname.Text + "', Gender = '" + Gender.Text + "', DOB = '" + Bday.Text + "', Address = '" + Address.Text + "', Phone= '" + Phone.Text + "', Email= '" + Email.Text + "', Position_ID= '" + Position.Text + "' where Employee_ID like '" + textBox1.Text + "'", cn);
                cm.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Record has been successfully updated", "Employee information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                f1.LoadRecords();
                this.Dispose();
            }
            catch(Exception ex)
            {
                cn.Close();
                MessageBox.Show("Warning: " + ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace Payroll
{
    public partial class Employee : Form
    {
        MySqlConnection cn;
        MySqlCommand cm;
        MySqlDataReader dr;
        addemp clscon = new addemp();
        string _id, _fname, _lname, _gender, _birthdate, _address, _phone, _email, _positionid;


        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]



        private static extern IntPtr CreateRoundRectRgn
            (
             int nLeft,
             int nTop,
             int nRight,
             int nBottom,
             int nWidthEllipse,
             int nHeightEll
             );

        public Employee()
        {
            InitializeComponent();
            cn = new MySqlConnection(clscon.dbconnect());
            LoadRecords();
        }

        private void dsh_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AddEmp_Click(object sender, EventArgs e)
        {
            addEmployee frm = new addEmployee(this);
            frm.AddEmp.Enabled = true;
            frm.update.Enabled = false;
            frm.ShowDialog();
        }

        public void LoadRecords()
        {
            int i = 0;
            dataGridView1.Rows.Clear();
            cn.Open();
            cm = new MySqlCommand("select * from employees order by Employee_ID, Fname, Lname, Gender", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {

                dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString(), dr[8].ToString());
            }
            dr.Close();
            cn.Close();
        }





        private void Employee_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
            MinimizeBox = false;
            FormBorderStyle = FormBorderStyle.None;
            AddEmp.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, AddEmp.Width, AddEmp.Height, 20, 20));

            this.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataGridView1.Columns[e.ColumnIndex].Name;
            if (colName == "colEdit")
            {
                addEmployee frm = new addEmployee(this);
                frm.AddEmp.Enabled = false;
                frm.update.Enabled = true;
                frm.textBox1.Enabled = false;
                frm.textBox1.Text = _id;
                frm.Fname.Text = _fname;
                frm.Lname.Text = _lname;
                frm.Gender.Text = _gender;
                frm.Bday.Text = _birthdate;
                frm.Address.Text = _address;
                frm.Phone.Text = _phone;
                frm.Email.Text = _email;
                frm.Position.Text = _positionid;
                frm.ShowDialog();
            }else if (colName =="colDelete")
            {
                if(MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new MySqlCommand("delete from employees where Employee_ID like '" + _id + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Record has been successfully deleted.", "Delete Record", MessageBoxButtons.OK  , MessageBoxIcon.Information);
                    LoadRecords();
                }
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            _id = dataGridView1[0, i].Value.ToString();
            _fname = dataGridView1[1, i].Value.ToString();
            _lname = dataGridView1[2, i].Value.ToString();
            _gender = dataGridView1[3, i].Value.ToString();
            _birthdate = dataGridView1[4, i].Value.ToString();
            _address = dataGridView1[5, i].Value.ToString();
            _phone = dataGridView1[6, i].Value.ToString();
            _email = dataGridView1[7, i].Value.ToString();
            _positionid = dataGridView1[8, i].Value.ToString();
        }
    }
}
